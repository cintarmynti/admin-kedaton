<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Edit Listing</h5>
        <p class="card-description">Listing yang telah diedit akan muncul di halaman listing</p>
        <form action="<?php echo e(route('listing.update', $listing->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="row">
                <div class="col">
                    <label for="">Alamat</label>
                  <input type="text" value="<?php echo e(old('alamat', $listing->alamat)); ?>" required class="form-control" name="alamat"  aria-label="First name">
                </div>
                <div class="col">
                    <label for="">No Rumah</label>
                  <input type="text" value="<?php echo e(old('no_rumah', $listing->no_rumah)); ?>" required class="form-control" name="no"  aria-label="Last name">
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <label for="">RT</label>
                  <input type="text" value="<?php echo e(old('RT', $listing->RT)); ?>" required class="form-control" name="RT" aria-label="First name">
                </div>
                <div class="col">
                    <label for="">RW</label>
                  <input type="text" value="<?php echo e(old('RW', $listing->RW)); ?>" required class="form-control" name="RW" aria-label="Last name">
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <label for="">Jumlah Lantai</label>
                  <input type="text" value="<?php echo e(old('lantai', $listing->lantai)); ?>" required class="form-control" name="lantai"  aria-label="First name">
                </div>
                <div class="col">
                    <label for="">Jumlah Kamar</label>
                  <input type="text" value="<?php echo e(old('jumlah_kamar', $listing->jumlah_kamar)); ?>" required class="form-control" name="jumlah_kamar"  aria-label="Last name">
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <label for="">Luas Kavling</label>

                    <div class="input-group mb-3">
                        <input type="number" value="<?php echo e(old('luas_tanah', $listing->luas_tanah)); ?>" min="0" required name="luas_tanah"  class="form-control"  aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <span class="input-group-text" id="basic-addon2">m2</span>
                      </div>
                </div>
                <div class="col">
                    <label for="">Luas Bangunan</label>
                    <div class="input-group mb-3">
                        <input type="number" value="<?php echo e(old('luas_bangunan', $listing->luas_bangunan)); ?>" min="0" required name="luas_bangunan"  class="form-control"  aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <span class="input-group-text" id="basic-addon2">m2</span>
                      </div>

                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <label for="">Penghuni</label>
                    <select class="form-select" name="penghuni" aria-label="Default select example">
                        <option disabled selected="">penghuni</option>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($lis->id); ?>" <?php echo e($lis->id == $listing->user_id_penghuni ? 'selected' : ''); ?>>
                                <?php echo e($lis->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>


                </div>
                <div class="col">
                    <label for="">Pemilik</label>

                    <select class="form-select" name="pemilik" aria-label="Default select example">
                        <option disabled selected="">pemilik</option>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($lis->id); ?>" <?php echo e($lis->id == $listing->user_id_pemilik ? 'selected' : ''); ?>>
                                <?php echo e($lis->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <label for="">Status Kepemilikan</label>
                    <select class="form-select" name="status" aria-label="Default select example">
                        <option disabled selected="">Status Kepemilikan</option>
                        <option value="dihuni" <?php echo e('dihuni' == $listing->status ? 'selected' : ''); ?>>dihuni</option>
                        <option value="disewakan" <?php echo e('disewakan' == $listing->status ? 'selected' : ''); ?>>disewakan</option>
                        <option value="dijual" <?php echo e('dijual' == $listing->status ? 'selected' : ''); ?>>dijual</option>
                      </select>
                </div>
                <div class="col">
                    <label for="">Harga</label>
                    <input type="text" value="<?php echo e(old('harga', $listing->harga)); ?>" required class="form-control" name="harga"  aria-label="Last name">
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md-6">
                    <label for="">Pilih Cluster</label>
                    <select class="form-select" name="status" aria-label="Default select example">
                        <option disabled selected="">Pilih Cluster</option>
                        <?php $__currentLoopData = $cluster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($clu->id); ?>" <?php echo e($clu->id == $listing->cluster_id ? 'selected' : ''); ?>>
                            <?php echo e($clu->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                </div>
            </div>

            <div class="row mt-4" id="images">
                <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 wrapper" >
                        <img onclick="image()" src="<?php echo e(url('files/' . $item->image)); ?>" width="200px" height="200px" alt="">
                        <div class="panjang">
                            <a href="<?php echo e(route('listingimg.delete', $item->id)); ?>" width="200px" class="btn btn-danger hapus mt-3">hapus gambar</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


            <div class="row mt-4">
                
            </div>
                <a href="<?php echo e(route('listing')); ?>" class="btn btn-warning mt-4">kembali</a>
                <button type="submit"  class="btn btn-primary ml-4 mt-4">Simpan</a>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    <script>
        function image() {
            const viewer = new Viewer(document.getElementById('images'), {
                viewed() {
                    viewer.zoomTo(1);
                },
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('before-style'); ?>
    <style>
        .wrapper {
            text-align: center;
           display: flex;
           flex-direction: column;
        }

        .panjang{
            width:200px;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project kedaton\admin-kedaton\resources\views/pages/listing/edit.blade.php ENDPATH**/ ?>