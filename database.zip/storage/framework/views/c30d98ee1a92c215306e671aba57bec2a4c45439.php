<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Tambahkan Otoritas Renovasi</h5>
        <p class="card-description">Otoritas Renovasi yang telah ditampilkan akan muncul di halaman renovasi</p>
        <form action="<?php echo e(route('renovasi.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="row mt-4">
                <div class="col">
                    <label for="">Nama User</label>
                    <select class="form-select" name="user_id" aria-label="Default select example">
                        <option disabled selected=""></option>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </select>
                </div>

            </div>

            <div class="row mt-4">
                <div class="col">
                    <label for="">Tanggal Mulai</label>
                    <input type="date" required class="form-control"  name="tanggal_mulai"  aria-label="Last name">
                  </div>
                <div class="col">
                    <label for="">Tanggal Akhir</label>
                    <input type="date" required class="form-control"  name="tanggal_akhir"  aria-label="Last name">
                </div>

            </div>

            <div class="row mt-4">
                <div class="col">
                    <label for="">Tambah Gambar</label>
                    <input required type="file" class="form-control" name="image[]" placeholder="tambah gambar" multiple>
                </div>

            </div>


            <div class="row mt-4">

                    <label for="">Catatan Renovasi</label>
                    <textarea class="post" class="form-control"  name="catatan_renovasi" aria-label="With textarea"></textarea>

                    <label for="">Catatan Biasa</label>
                    <textarea class="post"  name="catatan_biasa"  aria-label="With textarea"></textarea>

            </div>

            <div class="row mt-4">

            </div>

                <a href="<?php echo e(route('renovasi')); ?>" class="btn btn-warning mt-4">kembali</a>
                <button type="submit"  class="btn btn-primary ml-4 mt-4">Simpan</a>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
      $(".btn-success").click(function(){
          var lsthmtl = $(".clone").html();
          $(".increment").after(lsthmtl);
      });
      $("body").on("click",".btn-danger",function(){
          $(this).parents(".realprocode").remove();
      });
    });
</script>

<script>
      $(document).ready(function() {
        $('.post').summernote({
            placeholder: "Ketikan sesuatu disini . . .",
            height: '100'
        });
    });
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('before-style'); ?>
    <style>
        .form-label{
            font-weight: 500;
        }
    </style>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project kedaton\admin-kedaton\resources\views/pages/otoritas renovasi/create.blade.php ENDPATH**/ ?>