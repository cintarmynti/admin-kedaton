<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,700,800&display=swap" rel="stylesheet">
        <link href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/plugins/font-awesome/css/all.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/plugins/perfectscroll/perfect-scrollbar.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.css')); ?>" rel="stylesheet">


        <!-- Theme Styles -->
        <link href="<?php echo e(asset('assets/css/main.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
<?php /**PATH E:\project kedaton\admin-kedaton\resources\views/includes/style.blade.php ENDPATH**/ ?>