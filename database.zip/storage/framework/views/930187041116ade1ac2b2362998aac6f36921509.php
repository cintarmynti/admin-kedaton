<?php $__env->startSection('content'); ?>
    <div class="card" id="images">

        <div class="row mt-2" id="images">
            <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col wrapper" >
                    <img onclick="image()" src="<?php echo e(url('blog_image/' . $item->image)); ?>" width="200px" height="200px" alt="">
                    <div class="panjang">
                        <a href="<?php echo e(route('blogimg.delete', $item->id)); ?>" width="200px" class="btn btn-danger hapus mt-3">hapus gambar</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="m-5">
            <a href="<?php echo e(route('blog')); ?>" class="btn btn-warning mt-4">kembali</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    <script>
        function image() {
            const viewer = new Viewer(document.getElementById('images'), {
                viewed() {
                    viewer.zoomTo(1);
                },
            });
        }
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('before-style'); ?>
    <style>
        .wrapper {
            text-align: center;
            display: flex;
            flex-direction: column;
        }

        .panjang {
            width: 200px;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project kedaton\admin-kedaton\resources\views/pages/blog/detail.blade.php ENDPATH**/ ?>