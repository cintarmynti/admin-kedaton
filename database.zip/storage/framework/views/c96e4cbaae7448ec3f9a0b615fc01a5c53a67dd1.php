<div class="page-sidebar">
    <ul class="list-unstyled accordion-menu">
      <li class="sidebar-title">
        Main
      </li>
      <li  class="<?php echo e(Request::is('dashboard') ? 'active-page' : ''); ?>">
        <a href="<?php echo e(route('dashboard.index')); ?>"><i data-feather="home"></i>Dashboard</a>
      </li>
      

      <li class="<?php echo e(Request::is('user') ? 'active-page' : ''); ?>">
        <a href="<?php echo e(route('user')); ?>"><i data-feather="user"></i>Pengguna</a>
      </li>
      <li class="<?php echo e(Request::is('listing') ? 'active-page' : ''); ?>">
        <a href="<?php echo e(route('listing')); ?>"><i data-feather="calendar"></i>Listing</a>
      </li>


      <li class="<?php echo e(Request::is('banner') ? 'active-page' : ''); ?>">
        <a href="<?php echo e(route('banner')); ?>"><i data-feather="monitor"></i>Banner</a>
      </li>


      <li class="<?php echo e(Request::is('promo') ? 'active-page' : ''); ?>" class="active-page">
        <a href="<?php echo e(route('promo')); ?>"><i data-feather="paperclip"></i>Promo</a>
      </li>


      <li class="<?php echo e(Request::is('blog') ? 'active-page' : ''); ?>" class="active-page">
        <a href="<?php echo e(route('blog')); ?>"><i data-feather="file"></i>Blog</a>
      </li>

      <li class="<?php echo e(Request::is('renovasi') ? 'active-page' : ''); ?>">
        <a href="<?php echo e(route('renovasi')); ?>"><i data-feather="tool"></i>Otoritas Renovasi</a>
      </li>
      <li class="<?php echo e(Request::is('complain') ? 'active-page' : ''); ?>">
        <a href="<?php echo e(route('complain')); ?>"><i data-feather="alert-triangle"></i>Laporan Complain</a>
      </li>
      <li class="<?php echo e(Request::is('panic-button') ? 'active-page' : ''); ?>">
        <a href="<?php echo e(route('panic')); ?>"><i data-feather="activity"></i>Laporan Panic Button</a>
      </li>

      
    </ul>
</div>
<?php /**PATH E:\project kedaton\admin-kedaton\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>