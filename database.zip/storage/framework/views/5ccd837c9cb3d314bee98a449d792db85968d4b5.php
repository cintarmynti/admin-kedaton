<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Detail Bangunan</h5>
            <p class="card-description"></p>

            <div class="row mt-4">
                <div class="col">
                    <p>Alamat</p>
                    <p><?php echo e($listing->alamat); ?></p>
                </div>

                <div class="col">
                    <p>No Rumah</p>
                    <p><?php echo e($listing->no_rumah); ?></p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <p>RT</p>
                    <p><?php echo e($listing->RT); ?></p>
                </div>

                <div class="col">
                    <p>RW</p>
                    <p><?php echo e($listing->RW); ?></p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <p>Lantai</p>
                    <p><?php echo e($listing->lantai); ?></p>
                </div>

                <div class="col">
                    <p>Jumlah Kamar</p>
                    <p><?php echo e($listing->jumlah_kamar); ?></p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <p>Luas Kavling</p>
                    <p><?php echo e($listing->luas_tanah); ?></p>
                </div>

                <div class="col">
                    <p>Luas Bangunan</p>
                    <p><?php echo e($listing->luas_bangunan); ?></p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <p>Penghuni</p>
                    <p><?php echo e($listing->user_penghuni->name); ?></p>
                </div>

                <div class="col">
                    <p>Pemilik</p>
                    <p><?php echo e($listing->user_pemilik->name); ?></p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <p>Status</p>
                    <p><?php echo e($listing->status); ?></p>
                </div>

                <div class="col">
                    <p>Harga</p>
                    <p><?php echo e($listing->harga); ?></p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <p>Biaya IPKL</p>
                    <p>Rp <?php echo e(number_format($listing->tarif_ipkl, 2, ',', '.')); ?></p>

                </div>

            </div>

            <div class="row mt-2" id="images">
                <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col wrapper" >
                        <img onclick="image()" src="<?php echo e(url('files/' . $item->image)); ?>" width="200px" height="200px" alt="">
                        <div class="panjang">
                            <a href="<?php echo e(route('listingimg.delete', $item->id)); ?>" width="200px" class="btn btn-danger hapus mt-3">hapus gambar</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

        <div class="m-4">
            <a href="<?php echo e(route('listing')); ?>" class="btn btn-warning mt-4">kembali</a>

        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    <script>
        function image() {
            const viewer = new Viewer(document.getElementById('images'), {
                viewed() {
                    viewer.zoomTo(1);
                },
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('before-style'); ?>
    <style>
        .wrapper {
            text-align: center;
           display: flex;
           flex-direction: column;
        }

        .panjang{
            width:200px;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project kedaton\admin-kedaton\resources\views/pages/listing/detail.blade.php ENDPATH**/ ?>