<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Edit Blog</h5>
        <p class="card-description">blog yang telah diedit akan muncul di halaman Blog</p>
        <form action="<?php echo e(route('blog.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="row">
                <div class="col">
                    <label for="">Judul</label>
                  <input type="text" value="<?php echo e(old('judul', $blog->judul)); ?>" required class="form-control" name="judul"  aria-label="First name">
                </div>
                <div class="col-md-6">
                    <label for="">Foto Header</label>
                  <input type="file" class="form-control" name="photo_identitas" placeholder="photo identitas" aria-label="First name">
                </div>
            </div>

            <div class="row mt-1">

                <div class="col">
                    <label for="">Deskripsi</label>
                    <textarea id="post" class="form-control"  name="desc" aria-label="With textarea"><?php echo e(old('desc', $blog->desc)); ?></textarea>

                </div>
            </div>

            <div class="row mt-4" id="images">
                <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col wrapper" >
                        <img onclick="image()" src="<?php echo e(url('blog_image/' . $item->image)); ?>" width="200px" height="200px" alt="">
                        <div class="panjang">
                            <a href="<?php echo e(route('blogimg.delete', $item->id)); ?>" class="btn btn-danger hapus mt-3">hapus gambar</a>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


                <a href="<?php echo e(route('blog')); ?>" class="btn btn-warning mt-4">kembali</a>
                <button type="submit"  class="btn btn-primary ml-4 mt-4">Simpan</a>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
      $(".btn-success").click(function(){
          var lsthmtl = $(".clone").html();
          $(".increment").after(lsthmtl);
      });
      $("body").on("click",".btn-danger",function(){
          $(this).parents(".realprocode").remove();
      });
    });
</script>
<script>
    $(document).ready(function() {
        $('#post').summernote({
            placeholder: "Ketikan sesuatu disini . . .",
            height: '200'
        });
    });

    function image() {
            const viewer = new Viewer(document.getElementById('images'), {
                viewed() {
                    viewer.zoomTo(1);
                },
            });
        }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('before-style'); ?>
    <style>
        .form-label{
            font-weight: 500;
        }

        .wrapper {
            text-align: center;
           display: flex;
           flex-direction: column;
        }

        .panjang{
            width:200px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project kedaton\admin-kedaton\resources\views/pages/blog/edit.blade.php ENDPATH**/ ?>